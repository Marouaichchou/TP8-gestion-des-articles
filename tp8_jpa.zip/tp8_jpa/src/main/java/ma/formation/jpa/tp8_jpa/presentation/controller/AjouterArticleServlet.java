package ma.formation.jpa.tp8_jpa.presentation.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ma.formation.jpa.tp8_jpa.dao.DaoImplJPA;
import ma.formation.jpa.tp8_jpa.dao.IDao;
import ma.formation.jpa.tp8_jpa.dao.article.ArticleDaoImplJPA;
import ma.formation.jpa.tp8_jpa.dao.article.IArticleDao;
import ma.formation.jpa.tp8_jpa.service.IService;
import ma.formation.jpa.tp8_jpa.service.ServiceImpl;
import ma.formation.jpa.tp8_jpa.service.model.Article;

import java.io.IOException;

@WebServlet("/ajouter-article.do")
public class AjouterArticleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IService service = new ServiceImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.getRequestDispatcher("/view/ajouter-article.jsp").forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        String qteStr = request.getParameter("quantite");

        double price = Double.parseDouble(priceStr);
        double qte =  Double.parseDouble(qteStr);

        IArticleDao daoArticle = new ArticleDaoImplJPA();
        daoArticle.save(Article.builder().description(description).price(price).quantite(qte).build());
        response.sendRedirect("articles.do");

    }
}

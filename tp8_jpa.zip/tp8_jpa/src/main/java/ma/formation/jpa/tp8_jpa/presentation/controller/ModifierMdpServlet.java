package ma.formation.jpa.tp8_jpa.presentation.controller;
import jakarta.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;
import ma.formation.jpa.tp8_jpa.dao.*;
import ma.formation.jpa.tp8_jpa.service.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ma.formation.jpa.tp8_jpa.service.IService;
import ma.formation.jpa.tp8_jpa.service.ServiceImpl;
import java.io.IOException;


@WebServlet("/modifier-mdp.do")
public class ModifierMdpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IService service = new ServiceImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.getRequestDispatcher("/view/modifier-mdp.jsp").forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String mdp = request.getParameter("mdp");

        IDao dao = new DaoImplJPA();

        User user= dao.getUserByUsername(username);

        String hashedPassword = BCrypt.hashpw(mdp, BCrypt.gensalt());
        user.setPassword(hashedPassword);
        dao.save(user);
        response.sendRedirect("articles.do");


    }
}


package ma.formation.jpa.tp8_jpa.presentation.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ma.formation.jpa.tp8_jpa.dao.article.ArticleDaoImplJPA;
import ma.formation.jpa.tp8_jpa.dao.article.IArticleDao;
import ma.formation.jpa.tp8_jpa.service.IService;
import ma.formation.jpa.tp8_jpa.service.ServiceImpl;
import ma.formation.jpa.tp8_jpa.service.model.Article;

@WebServlet("/supprimer.do")

public class SupprimerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IService service = new ServiceImpl();
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        long id = Long.parseLong(idStr);
        IArticleDao daoArticle = new ArticleDaoImplJPA();
        daoArticle.delete(id);
        response.sendRedirect("articles.do");
    }
    }

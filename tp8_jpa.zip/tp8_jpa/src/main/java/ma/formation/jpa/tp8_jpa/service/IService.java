package ma.formation.jpa.tp8_jpa.service;

import java.util.List;

import ma.formation.jpa.tp8_jpa.service.model.Article;

public interface IService {
    Boolean checkAccount(String username, String password);

    List<Article> getAllArticle();
}
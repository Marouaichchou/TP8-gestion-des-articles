package ma.formation.jpa.tp8_jpa.service;

import java.util.List;
import org.mindrot.jbcrypt.BCrypt;

import ma.formation.jpa.tp8_jpa.dao.DaoImplJPA;
import ma.formation.jpa.tp8_jpa.dao.IDao;
import ma.formation.jpa.tp8_jpa.dao.article.ArticleDaoImplJPA;
import ma.formation.jpa.tp8_jpa.dao.article.IArticleDao;
import ma.formation.jpa.tp8_jpa.service.model.Article;
import ma.formation.jpa.tp8_jpa.service.model.User;

public class ServiceImpl implements IService {
    private IDao dao = new DaoImplJPA();
    private IArticleDao daoArticle = new ArticleDaoImplJPA();

    @Override
    public Boolean checkAccount(String username, String password) {
        User user = dao.getUserByUsername(username);
        if (user == null) {
            return false;
        } else {

            String hashedPasswordFromDB = user.getPassword();

            return BCrypt.checkpw(password, hashedPasswordFromDB);
        }
    }

    @Override
    public List<Article> getAllArticle() {
        return daoArticle.findAll();
    }
}
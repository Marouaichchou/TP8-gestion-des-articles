package ma.formation.jpa;

public class Test {
}
